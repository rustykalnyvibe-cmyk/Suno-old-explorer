# Suno Old Explorer Worker

Worker pośredniczący dla strony Suno Old Explorer.

Endpoints:
- GET /health
- GET /random?model=both&tries=15
- GET /random?model=v4&tries=15
- GET /random?model=v4.5&tries=15

Nie wymaga klucza API. Korzysta z publicznej listy ID oraz publicznych danych
klipu. Endpoint Suno może się zmienić, więc projekt jest eksperymentalny.
